import { Welcome } from './Welcome';

export default {
  title: 'Welcome',
};

export const Usage = () => <Welcome />;
