import logo from "@/public/logoPng.png";
import {Image} from "@mantine/core";


export function MyLogo() {
    return (
        <>
            
        </>
    );
}