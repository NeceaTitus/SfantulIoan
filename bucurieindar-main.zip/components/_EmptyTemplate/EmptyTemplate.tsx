
import classes from './_EmptyTemplate.module.css';

export function _EmptyTemplate() {
    return <>
        </>;
}