export const contactInfo = {
    email: "office@bucurieindar.ro",
    phone: "+4 0727 786 725",
    phoneForWhatsapp: "40727786725",
    address: "Str. Poteraș 14, București, România 040266",
    facebookLink: "https://www.facebook.com/asociatiabucurieindar",
};